<?php
require("includes/config.inc.php");
require("includes/common.inc.php");
require("includes/conn.inc.php");

echo "<h3>POST-Daten:</h3>";
ta($_POST);

// Filter 
$where = ""; // Initialisierung der $where-Variable

    //////////////
    if (count($_POST) > 0) {
        // Postdaten vorhanden
        $NachnameFilter = "";
        $VornameFilter = "";

        $VornameFilter = "tbl_user.Vorname = '" . $_POST["fVorname"] . "'";
    }
    
    if(strlen($_POST["fNachname"]) > 0){
        $NachnameFilter = "tbl_user.Nachname = '" . $_POST["fNachname"] . "'";
    }
    
    ta($VornameFilter);
    ta($NachnameFilter);

    if(strlen($_POST["fVorname"]) > 0){
    if (strlen($VornameFilter)> 0 && strlen($NachnameFilter) > 0) {
        $where = "WHERE ( " . $VornameFilter . " AND " . $NachnameFilter. " )";
        } else if (strlen($VornameFilter) > 0 && !strlen($NachnameFilter) > 0){
            $where = "WHERE ( " . $VornameFilter . " )"; 
        } else if (!strlen($VornameFilter) > 0 && strlen($NachnameFilter) > 0){
            $where = "WHERE ( " . $NachnameFilter . " )";
        } else {
            $where = "";
        }

        echo "<h1> $where </h1>";
    }

?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="includes/common.css">
    <title>Auswertung Vortragende</title>
</head>
<body>

    <nav>
            <ul>
                <li><a href="index.php">Startseite</a></li>
                <li><a href="rezeptdarstellung.php">Rezeptdarstellung</a></li>
                <li><a href="ZutatenrezeptView.php">Zutaten und Rezepte</a></li>
            </ul>
        </nav>
        <h1>Rezept je User</h1>
        <p>Bitte wählen Sie aus der obigen Navigation.</p>

    <main>
        <form method = "post">
            <ul>
                <br>
                <br>
                <h2>User filtern:</h2>
                <label for="fVorname">Vorname</label>
                <input type="text" name="fVorname">
                <br>
                <label for="yearBis">Nachname</label>
                <input type="text" name="fNachname">
                <br>
                <input type="submit" value="filtern">
            </ul>
        </form>
        <br><br>
        <?php 
        $sql = "
            SELECT
                tbl_rezepte.Titel,
                tbl_rezepte.Beschreibung,
                tbl_user.Vorname,
                tbl_user.Nachname,
                tbl_user.Emailadresse
            FROM tbl_user
            INNER JOIN tbl_rezepte ON tbl_rezepte.FIDUser = tbl_user.IDUser
            " . $where . "
            ORDER BY tbl_user.Nachname ASC 
            ";

        $rezepte = $conn->query($sql) or die ("Fehler in der Query $sql");

        echo "<h3> Rezepte nach User</h3>";

        echo "<ul>";

        While($r = $rezepte->fetch_object()){
            echo " <li> Name: ". $r->Vorname . " " . $r->Nachname . " <br>  Rezept: " . $r->Titel . "<br> Beschreibung:  " .$r->Beschreibung . "<br><br>";
        }

        echo "</ul>";

        ?>


    </main>

</body>
</html>
