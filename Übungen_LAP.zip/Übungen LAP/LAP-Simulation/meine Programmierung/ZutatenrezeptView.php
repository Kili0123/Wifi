<?php
require("includes/config.inc.php");
require("includes/common.inc.php");
require("includes/conn.inc.php");

echo "<h3>POST-Daten:</h3>";
//ta($_POST["zutatenSelect"]);

if(isset($_POST["zutatenSelect"]))
{
    echo "ZutatenID: " . $_POST["zutatenSelect"];
}


/** */
//ta($_POST["zutatenSelect"]);
//echo "ZutatenSelectID: " . $_POST["zutatenSelect"];

// Filter 
$where = ""; // Initialisierung der $where-Variable


?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="includes/common.css">
    <title>Rezepte je Zutat</title>
</head>
<body>

    <nav>
            <ul>
                <li><a href="index.php">Startseite</a></li>
                <li><a href="rezeptdarstellung.php">Rezeptdarstellung</a></li>
                <li><a href="zutatenrezeptview.php">Zutaten und Rezepte</a></li>
            </ul>
        </nav>
        <h1>Rezept je Zutat</h1>
    
    <main>
        <label for="zutatenSelect">Zutaten:</label>
            <form method="POST">
                <br>
                <select name="zutatenSelect">
                    <?php
                        
                        $sql = "
                                SELECT 
                                    tbl_zutaten.Bezeichnung,
                                    tbl_zutaten.IDZutat
                                FROM tbl_zutaten
                                ";

                        $zutatenResult = $conn->query($sql) or die ("Fehler in der Query $sql");
                        
                        echo "<option value = \"0\" Zutat: > Wählen Sie eine Zutat </option>";

                        while($z = $zutatenResult->fetch_object()){
                            
                            echo '<option value="'.$z->IDZutat.'" >'.$z->Bezeichnung.'</option>'; 
                        }

                        echo "ZutatenID: " . $_POST["zutatenSelect"];
                    ?>
                </select>            
                <input type="submit" value="filtern" ></input>
            </form>

        <br><br>
        <?php 

                        

            $sql = "
            SELECT
                tbl_rezepte.Titel,
                tbl_rezepte.AnzahlPersonen,
                tbl_user.Vorname,
                tbl_user.Nachname
            FROM tbl_zutaten
            INNER JOIN tbl_rezepte_zutaten ON tbl_zutaten.IDZutat = tbl_rezepte_zutaten.FIDZutat
            INNER JOIN tbl_rezepte ON tbl_rezepte.IDRezept = tbl_rezepte_zutaten.FIDRezept  
            INNER JOIN tbl_user ON tbl_rezepte.FIDUser = tbl_user.IDUser
            WHERE ( tbl_zutaten.IDZutat = " . $_POST["zutatenSelect"] . " )";
            
            $RezepteResult = $conn->query($sql) or die ("Fehler in der Query".$sql);
            while($rezept = $RezepteResult->fetch_object()){
                echo "Rezept: " . $rezept->Titel . "( von " . $rezept->Vorname. " " . $rezept->Nachname . ", für: " . $rezept->AnzahlPersonen . " Personen ) <br>";
            }

        ?>


    </main>

</body>
</html>
