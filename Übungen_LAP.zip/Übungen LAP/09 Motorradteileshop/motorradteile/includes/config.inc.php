<?php
define("TESTMODUS",1);
define("DB",[
    "host" => "localhost",
    "user" => "root",
    "pwd" => "",
    "name" => "db_lap_motorradteile"
]);
?>