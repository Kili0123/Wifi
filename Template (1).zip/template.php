<?php
require("includes/common.inc.php");
require("includes/config.inc.php");
require("includes/conn.inc.php");


?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/common.css">
    <title>Überschrift</title>
</head>

<body>
    <main>
        <h1>Überschrift</h1>

    </main>

    </form>
    
</body>
</html>