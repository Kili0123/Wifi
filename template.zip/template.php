<?php
require("includes/common.inc.php");
require("includes/config.inc.php");
require("includes/conn.inc.php");


?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/common.css">
    <title>Überschrift</title>
</head>

<body>
    <h1>Überschrift</h1>
    <nav>
        <ul>
            <li><a href="datei1.php">datei1</a></li>
            <li><a href="datei2.php">datei2</a></li>
        </ul>
    </nav>
    <main>

    </main>

    
</body>
</html>